
  # Music Listening Website

  This is a code bundle for Music Listening Website. The original project is available at https://www.figma.com/design/tbiN0UFvnMlESMN3KIZ11A/Music-Listening-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  