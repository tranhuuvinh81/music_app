import { useState, useEffect, useMemo } from "react";
import { MusicPlayer } from "./components/MusicPlayer";
import { Playlist } from "./components/Playlist";
import { CategorySidebar } from "./components/CategorySidebar";
import { Music, Search } from "lucide-react";
import { Input } from "./components/ui/input";

interface Song {
  id: number;
  title: string;
  artist: string;
  album: string;
  duration: string;
  coverUrl: string;
  genre: string;
}

const mockSongs: Song[] = [
  // Rock
  {
    id: 1,
    title: "Thunder Road",
    artist: "The Rock Legends",
    album: "Highway Dreams",
    duration: "4:23",
    genre: "rock",
    coverUrl: "https://images.unsplash.com/photo-1616688920494-6758cf681803?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyb2NrJTIwYmFuZCUyMGNvbmNlcnR8ZW58MXx8fHwxNzYwMjUwNDM2fDA&ixlib=rb-4.1.0&q=80&w=1080",
  },
  {
    id: 2,
    title: "Electric Sunset",
    artist: "Neon Strings",
    album: "Live at the Boulevard",
    duration: "5:12",
    genre: "rock",
    coverUrl: "https://images.unsplash.com/photo-1734556803558-2635adcc320b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxndWl0YXIlMjBjb25jZXJ0fGVufDF8fHx8MTc2MDI0OTMyMHww&ixlib=rb-4.1.0&q=80&w=1080",
  },
  {
    id: 3,
    title: "Revolution Now",
    artist: "The Rebels",
    album: "Uprising",
    duration: "4:45",
    genre: "rock",
    coverUrl: "https://images.unsplash.com/photo-1616688920494-6758cf681803?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyb2NrJTIwYmFuZCUyMGNvbmNlcnR8ZW58MXx8fHwxNzYwMjUwNDM2fDA&ixlib=rb-4.1.0&q=80&w=1080",
  },
  // Jazz
  {
    id: 4,
    title: "Smooth Velvet",
    artist: "The Jazz Lounge",
    album: "After Hours",
    duration: "4:56",
    genre: "jazz",
    coverUrl: "https://images.unsplash.com/photo-1725830071503-d705ef4a0975?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxqYXp6JTIwbXVzaWN8ZW58MXx8fHwxNzYwMjQ5MzIxfDA&ixlib=rb-4.1.0&q=80&w=1080",
  },
  {
    id: 5,
    title: "Midnight Blue",
    artist: "The Saxophone Quartet",
    album: "Blue Note Sessions",
    duration: "6:12",
    genre: "jazz",
    coverUrl: "https://images.unsplash.com/photo-1725830071503-d705ef4a0975?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxqYXp6JTIwbXVzaWN8ZW58MXx8fHwxNzYwMjQ5MzIxfDA&ixlib=rb-4.1.0&q=80&w=1080",
  },
  {
    id: 6,
    title: "Bebop Dreams",
    artist: "Charlie's Ensemble",
    album: "Modern Jazz Classics",
    duration: "5:34",
    genre: "jazz",
    coverUrl: "https://images.unsplash.com/photo-1725830071503-d705ef4a0975?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxqYXp6JTIwbXVzaWN8ZW58MXx8fHwxNzYwMjQ5MzIxfDA&ixlib=rb-4.1.0&q=80&w=1080",
  },
  // Classical
  {
    id: 7,
    title: "Ivory Memories",
    artist: "Classical Modernists",
    album: "Piano Reflections",
    duration: "6:34",
    genre: "classical",
    coverUrl: "https://images.unsplash.com/photo-1538402074774-8e624f3f7e5d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwaWFubyUyMGtleXN8ZW58MXx8fHwxNzYwMjM5MzYzfDA&ixlib=rb-4.1.0&q=80&w=1080",
  },
  {
    id: 8,
    title: "Symphony No. 9",
    artist: "The Philharmonic Orchestra",
    album: "Greatest Symphonies",
    duration: "8:23",
    genre: "classical",
    coverUrl: "https://images.unsplash.com/photo-1587834423414-9545adae44ff?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjbGFzc2ljYWwlMjBvcmNoZXN0cmF8ZW58MXx8fHwxNzYwMjUwNDM3fDA&ixlib=rb-4.1.0&q=80&w=1080",
  },
  {
    id: 9,
    title: "Moonlight Sonata",
    artist: "Piano Masters",
    album: "Beethoven Collection",
    duration: "5:45",
    genre: "classical",
    coverUrl: "https://images.unsplash.com/photo-1538402074774-8e624f3f7e5d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwaWFubyUyMGtleXN8ZW58MXx8fHwxNzYwMjM5MzYzfDA&ixlib=rb-4.1.0&q=80&w=1080",
  },
  // Electronic
  {
    id: 10,
    title: "Neon Lights",
    artist: "Synthwave Orchestra",
    album: "Retro Future",
    duration: "5:02",
    genre: "electronic",
    coverUrl: "https://images.unsplash.com/photo-1606877079930-4a900904b2a4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbGVjdHJvbmljJTIwZGolMjBtdXNpY3xlbnwxfHx8fDE3NjAyNTA0MzZ8MA&ixlib=rb-4.1.0&q=80&w=1080",
  },
  {
    id: 11,
    title: "Digital Dreams",
    artist: "Cyber Pulse",
    album: "Binary Nights",
    duration: "4:18",
    genre: "electronic",
    coverUrl: "https://images.unsplash.com/photo-1606877079930-4a900904b2a4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbGVjdHJvbmljJTIwZGolMjBtdXNpY3xlbnwxfHx8fDE3NjAyNTA0MzZ8MA&ixlib=rb-4.1.0&q=80&w=1080",
  },
  {
    id: 12,
    title: "Frequency Waves",
    artist: "Echo Chamber",
    album: "Digital Silence",
    duration: "3:45",
    genre: "electronic",
    coverUrl: "https://images.unsplash.com/photo-1747494750675-d1aecb8672b3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoZWFkcGhvbmVzJTIwbXVzaWN8ZW58MXx8fHwxNzYwMjQ5MzIwfDA&ixlib=rb-4.1.0&q=80&w=1080",
  },
  // Pop
  {
    id: 13,
    title: "Summer Nights",
    artist: "Pop Stars United",
    album: "Hits Collection",
    duration: "3:32",
    genre: "pop",
    coverUrl: "https://images.unsplash.com/photo-1684679106461-dae134df8da6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwb3AlMjBtdXNpYyUyMGNvbmNlcnR8ZW58MXx8fHwxNzYwMjA3MzQyfDA&ixlib=rb-4.1.0&q=80&w=1080",
  },
  {
    id: 14,
    title: "Dancing Queen",
    artist: "The Pop Collective",
    album: "Dance Floor Anthems",
    duration: "4:05",
    genre: "pop",
    coverUrl: "https://images.unsplash.com/photo-1684679106461-dae134df8da6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwb3AlMjBtdXNpYyUyMGNvbmNlcnR8ZW58MXx8fHwxNzYwMjA3MzQyfDA&ixlib=rb-4.1.0&q=80&w=1080",
  },
  {
    id: 15,
    title: "Heartbeat",
    artist: "Luna Wave",
    album: "Pop Revolution",
    duration: "3:48",
    genre: "pop",
    coverUrl: "https://images.unsplash.com/photo-1684679106461-dae134df8da6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwb3AlMjBtdXNpYyUyMGNvbmNlcnR8ZW58MXx8fHwxNzYwMjA3MzQyfDA&ixlib=rb-4.1.0&q=80&w=1080",
  },
  // Folk
  {
    id: 16,
    title: "Acoustic Journey",
    artist: "Folk Wanderers",
    album: "Open Roads",
    duration: "4:15",
    genre: "folk",
    coverUrl: "https://images.unsplash.com/photo-1734556803558-2635adcc320b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxndWl0YXIlMjBjb25jZXJ0fGVufDF8fHx8MTc2MDI0OTMyMHww&ixlib=rb-4.1.0&q=80&w=1080",
  },
  {
    id: 17,
    title: "Mountain Breeze",
    artist: "The Travelers",
    album: "Wanderlust",
    duration: "5:28",
    genre: "folk",
    coverUrl: "https://images.unsplash.com/photo-1734556803558-2635adcc320b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxndWl0YXIlMjBjb25jZXJ0fGVufDF8fHx8MTc2MDI0OTMyMHww&ixlib=rb-4.1.0&q=80&w=1080",
  },
  {
    id: 18,
    title: "Midnight Dreams",
    artist: "The Vinyl Collective",
    album: "Analog Nights",
    duration: "4:23",
    genre: "folk",
    coverUrl: "https://images.unsplash.com/photo-1677799562106-0e3edc7dce45?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtdXNpYyUyMGFsYnVtJTIwdmlueWx8ZW58MXx8fHwxNzYwMTYwMjk3fDA&ixlib=rb-4.1.0&q=80&w=1080",
  },
];

export default function App() {
  const [currentSong, setCurrentSong] = useState<Song>(mockSongs[0]);
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [volume, setVolume] = useState(70);
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");

  // Get unique genres and their counts
  const categories = useMemo(() => {
    const genreCounts = mockSongs.reduce((acc, song) => {
      acc[song.genre] = (acc[song.genre] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    const categoryList = [
      { id: "all", name: "All Songs", icon: Music, count: mockSongs.length },
      { id: "rock", name: "Rock", icon: Music, count: genreCounts.rock || 0 },
      { id: "jazz", name: "Jazz", icon: Music, count: genreCounts.jazz || 0 },
      { id: "classical", name: "Classical", icon: Music, count: genreCounts.classical || 0 },
      { id: "electronic", name: "Electronic", icon: Music, count: genreCounts.electronic || 0 },
      { id: "pop", name: "Pop", icon: Music, count: genreCounts.pop || 0 },
      { id: "folk", name: "Folk", icon: Music, count: genreCounts.folk || 0 },
    ];

    return categoryList;
  }, []);

  // Filter songs based on category and search
  const filteredSongs = useMemo(() => {
    let songs = mockSongs;

    // Filter by category
    if (selectedCategory !== "all") {
      songs = songs.filter((song) => song.genre === selectedCategory);
    }

    // Filter by search query
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      songs = songs.filter(
        (song) =>
          song.title.toLowerCase().includes(query) ||
          song.artist.toLowerCase().includes(query) ||
          song.album.toLowerCase().includes(query)
      );
    }

    return songs;
  }, [selectedCategory, searchQuery]);

  // Get playlist title
  const playlistTitle = useMemo(() => {
    if (searchQuery.trim()) {
      return `Search results for "${searchQuery}"`;
    }
    const category = categories.find((cat) => cat.id === selectedCategory);
    return category?.name || "Your Playlist";
  }, [selectedCategory, searchQuery, categories]);

  // Simulate progress
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isPlaying) {
      interval = setInterval(() => {
        setProgress((prev) => {
          if (prev >= 100) {
            handleNext();
            return 0;
          }
          return prev + 0.5;
        });
      }, 500);
    }
    return () => clearInterval(interval);
  }, [isPlaying, filteredSongs, currentSong]);

  const handlePlayPause = () => {
    setIsPlaying(!isPlaying);
  };

  const handleNext = () => {
    const currentIndex = filteredSongs.findIndex((song) => song.id === currentSong.id);
    if (currentIndex === -1) {
      // Current song not in filtered list, play first song
      if (filteredSongs.length > 0) {
        setCurrentSong(filteredSongs[0]);
        setProgress(0);
        setIsPlaying(true);
      }
      return;
    }
    const nextIndex = (currentIndex + 1) % filteredSongs.length;
    setCurrentSong(filteredSongs[nextIndex]);
    setProgress(0);
    setIsPlaying(true);
  };

  const handlePrevious = () => {
    const currentIndex = filteredSongs.findIndex((song) => song.id === currentSong.id);
    if (currentIndex === -1) {
      // Current song not in filtered list, play first song
      if (filteredSongs.length > 0) {
        setCurrentSong(filteredSongs[0]);
        setProgress(0);
        setIsPlaying(true);
      }
      return;
    }
    const prevIndex = currentIndex === 0 ? filteredSongs.length - 1 : currentIndex - 1;
    setCurrentSong(filteredSongs[prevIndex]);
    setProgress(0);
    setIsPlaying(true);
  };

  const handleSongSelect = (song: Song) => {
    setCurrentSong(song);
    setProgress(0);
    setIsPlaying(true);
  };

  const handleProgressChange = (value: number[]) => {
    setProgress(value[0]);
  };

  const handleVolumeChange = (value: number[]) => {
    setVolume(value[0]);
  };

  const handleCategorySelect = (categoryId: string) => {
    setSelectedCategory(categoryId);
    setSearchQuery(""); // Clear search when changing category
  };

  return (
    <div className="size-full flex flex-col bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center gap-6">
          <div className="flex items-center gap-3">
            <Music className="h-8 w-8 text-primary" />
            <h1>MusicStream</h1>
          </div>
          <div className="flex-1 max-w-md">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                type="text"
                placeholder="Search songs, artists, or albums..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="flex-1 flex overflow-hidden">
        <CategorySidebar
          categories={categories}
          selectedCategory={selectedCategory}
          onCategorySelect={handleCategorySelect}
        />
        <Playlist
          songs={filteredSongs}
          currentSong={currentSong}
          isPlaying={isPlaying}
          onSongSelect={handleSongSelect}
          onPlayPause={handlePlayPause}
          playlistTitle={playlistTitle}
          songCount={filteredSongs.length}
        />
      </div>

      {/* Player */}
      <MusicPlayer
        currentSong={currentSong}
        isPlaying={isPlaying}
        onPlayPause={handlePlayPause}
        onNext={handleNext}
        onPrevious={handlePrevious}
        progress={progress}
        onProgressChange={handleProgressChange}
        volume={volume}
        onVolumeChange={handleVolumeChange}
      />
    </div>
  );
}
