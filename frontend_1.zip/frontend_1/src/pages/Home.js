import React, { useEffect, useState } from 'react';
import API from '../api/api';
import AudioPlayer from '../components/AudioPlayer';

export default function Home() {
  const [songs, setSongs] = useState([]);
  const [current, setCurrent] = useState(null);

  useEffect(() => {
    API.get('/songs').then(res => setSongs(res.data)).catch(err => {
      console.error(err);
    });
  }, []);

  return (
    <div className="container">
      <h2>Danh sách bài hát</h2>
      <table>
        <thead>
          <tr><th>Title</th><th>Artist</th><th>Album</th><th>Genre</th><th>Year</th><th></th></tr>
        </thead>
        <tbody>
          {songs.map(s => (
            <tr key={s.id}>
              <td>{s.title}</td>
              <td>{s.artist}</td>
              <td>{s.album || '-'}</td>
              <td>{s.genre || '-'}</td>
              <td>{s.release_year || '-'}</td>
              <td>
                <button className="btn" onClick={() => setCurrent(s)}>Play</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {current && (
        <div style={{marginTop:16}}>
          <AudioPlayer src={`http://localhost:5000${current.file_url}`} title={current.title} />
        </div>
      )}
    </div>
  );
}
