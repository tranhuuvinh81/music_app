import React, { useState, useContext } from 'react';
import API from '../api/api';
import { AuthContext } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';

export default function Login() {
  const [form, setForm] = useState({username:'', password:''});
  const [error, setError] = useState('');
  const { login } = useContext(AuthContext);
  const navigate = useNavigate();

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    try {
      // call /api/users/login (matches backend userRoutes)
      const res = await API.post('/users/login', form);
      // backend may return token and user; if not, fetch user info
      const token = res.data.token;
      // attempt to get user object from response, otherwise get profile
      const user = res.data.user || {};
      // If backend didn't return user payload, we will decode minimal info by requesting /api/users (or you can store username)
      login(user, token);
      navigate('/');
    } catch (err) {
      console.error(err);
      setError(err.response?.data?.message || 'Login failed');
    }
  };

  return (
    <div className="container" style={{maxWidth:420}}>
      <h2>Đăng nhập</h2>
      <form onSubmit={submit}>
        <input placeholder="username" value={form.username} onChange={e=>setForm({...form,username:e.target.value})} />
        <input type="password" placeholder="password" value={form.password} onChange={e=>setForm({...form,password:e.target.value})} />
        <button className="btn" type="submit">Login</button>
      </form>
      {error && <p style={{color:'red'}}>{error}</p>}
    </div>
  );
}
