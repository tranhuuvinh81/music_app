import React, { useState } from 'react';
import API from '../api/api';
import { useNavigate } from 'react-router-dom';

export default function Register() {
  const [form, setForm] = useState({username:'', password:'', full_name:'', age:'', email:'', phone:''});
  const navigate = useNavigate();

  const submit = async (e) => {
    e.preventDefault();
    try {
      await API.post('/users', form); // many backends use /api/users for register
      alert('Registered successfully');
      navigate('/login');
    } catch (err) {
      alert(err.response?.data?.message || 'Register failed');
    }
  };

  return (
    <div className="container" style={{maxWidth:600}}>
      <h2>Register</h2>
      <form onSubmit={submit}>
        <input placeholder="username" onChange={e=>setForm({...form,username:e.target.value})} />
        <input type="password" placeholder="password" onChange={e=>setForm({...form,password:e.target.value})} />
        <input placeholder="Full name" onChange={e=>setForm({...form,full_name:e.target.value})} />
        <input placeholder="Age" onChange={e=>setForm({...form,age:e.target.value})} />
        <input placeholder="Email" onChange={e=>setForm({...form,email:e.target.value})} />
        <input placeholder="Phone" onChange={e=>setForm({...form,phone:e.target.value})} />
        <button className="btn" type="submit">Register</button>
      </form>
    </div>
  );
}
