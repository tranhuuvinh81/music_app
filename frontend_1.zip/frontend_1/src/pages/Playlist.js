import React, { useEffect, useState, useContext } from 'react';
import API from '../api/api';
import { AuthContext } from '../context/AuthContext';

export default function Playlist() {
  const { user } = useContext(AuthContext);
  const [playlists, setPlaylists] = useState([]);
  const [name, setName] = useState('');

  useEffect(()=> {
    if (user) {
      API.get(`/playlists/user/${user.id}`).then(res=>setPlaylists(res.data));
    }
  }, [user]);

  const create = async () => {
    await API.post('/playlists', { user_id: user.id, name, description: '' });
    setName('');
    const res = await API.get(`/playlists/user/${user.id}`);
    setPlaylists(res.data);
  };

  return (
    <div className="container">
      <h2>Your Playlists</h2>
      <div style={{maxWidth:400}}>
        <input placeholder="Playlist name" value={name} onChange={e=>setName(e.target.value)} />
        <button className="btn" onClick={create}>Create</button>
      </div>

      <ul>
        {playlists.map(p=>(
          <li key={p.id}>{p.name}</li>
        ))}
      </ul>
    </div>
  );
}
