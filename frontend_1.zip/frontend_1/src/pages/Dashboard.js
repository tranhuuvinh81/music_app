import React, { useEffect, useState, useContext } from 'react';
import API from '../api/api';
import { AuthContext } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';

export default function Dashboard() {
  const { user, logout } = useContext(AuthContext);
  const navigate = useNavigate();
  const [users, setUsers] = useState([]);
  const [songs, setSongs] = useState([]);
  const [songForm, setSongForm] = useState({title:'', artist:'', album:'', genre:'', release_year:'', file_url:''});

  useEffect(()=> {
    if (!user) navigate('/login');
    if (user && user.role !== 'admin') {
      // redirect non-admin
      navigate('/');
    } else {
      fetchData();
    }
  }, [user]);

  const fetchData = async () => {
    const [uRes, sRes] = await Promise.all([API.get('/users'), API.get('/songs')]);
    setUsers(uRes.data);
    setSongs(sRes.data);
  };

  const deleteUser = async (id) => {
    if (!confirm('Delete user?')) return;
    await API.delete(`/users/${id}`);
    fetchData();
  };

  const deleteSong = async (id) => {
    if (!confirm('Delete song?')) return;
    await API.delete(`/songs/${id}`);
    fetchData();
  };

  const addSong = async (e) => {
    e.preventDefault();
    await API.post('/songs', songForm);
    setSongForm({title:'', artist:'', album:'', genre:'', release_year:'', file_url:''});
    fetchData();
  };

  return (
    <div className="container">
      <h2>Admin Dashboard</h2>
      <p>Welcome, {user?.username} <button className="btn" onClick={()=>{logout(); navigate('/login');}}>Logout</button></p>

      <h3>Users</h3>
      <table>
        <thead><tr><th>Id</th><th>Username</th><th>Full name</th><th>Email</th><th>Role</th><th>Actions</th></tr></thead>
        <tbody>
          {users.map(u=>(
            <tr key={u.id}>
              <td>{u.id}</td>
              <td>{u.username}</td>
              <td>{u.full_name}</td>
              <td>{u.email}</td>
              <td>{u.role}</td>
              <td><button className="btn" onClick={()=>deleteUser(u.id)}>Delete</button></td>
            </tr>
          ))}
        </tbody>
      </table>

      <h3>Add song</h3>
      <form onSubmit={addSong} style={{maxWidth:600}}>
        <input placeholder="Title" value={songForm.title} onChange={e=>setSongForm({...songForm,title:e.target.value})} />
        <input placeholder="Artist" value={songForm.artist} onChange={e=>setSongForm({...songForm,artist:e.target.value})} />
        <input placeholder="Album" value={songForm.album} onChange={e=>setSongForm({...songForm,album:e.target.value})} />
        <input placeholder="Genre" value={songForm.genre} onChange={e=>setSongForm({...songForm,genre:e.target.value})} />
        <input placeholder="Year" value={songForm.release_year} onChange={e=>setSongForm({...songForm,release_year:e.target.value})} />
        <input placeholder="file_url (e.g. /uploads/songs/xxx.mp3)" value={songForm.file_url} onChange={e=>setSongForm({...songForm,file_url:e.target.value})} />
        <button className="btn" type="submit">Add Song</button>
      </form>

      <h3>Songs</h3>
      <table>
        <thead><tr><th>Id</th><th>Title</th><th>Artist</th><th>Actions</th></tr></thead>
        <tbody>
          {songs.map(s=>(
            <tr key={s.id}>
              <td>{s.id}</td>
              <td>{s.title}</td>
              <td>{s.artist}</td>
              <td><button className="btn" onClick={()=>deleteSong(s.id)}>Delete</button></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
