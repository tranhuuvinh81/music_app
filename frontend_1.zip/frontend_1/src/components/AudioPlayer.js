import React from 'react';

export default function AudioPlayer({ src, title }) {
  return (
    <div>
      <h4>Now playing: {title}</h4>
      <audio controls autoPlay style={{width:'100%'}}>
        <source src={src} type="audio/mpeg" />
        Your browser does not support audio.
      </audio>
    </div>
  );
}
