import React, { useContext } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';

export default function Navbar() {
  const { user, logout } = useContext(AuthContext);
  const navigate = useNavigate();

  const onLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <nav>
      <div className="container" style={{display:'flex', alignItems:'center', justifyContent:'space-between'}}>
        <div>
          <Link to="/">Home</Link>
          {user && user.role === 'admin' && <Link to="/dashboard">Dashboard</Link>}
          {user && <Link to="/playlist">Playlists</Link>}
        </div>
        <div>
          {!user && <Link to="/login">Login</Link>}
          {!user && <Link to="/register">Register</Link>}
          {user && <span style={{marginRight:12}}>Hello, {user.username}</span>}
          {user && <button className="btn" onClick={onLogout}>Logout</button>}
        </div>
      </div>
    </nav>
  );
}
