# Frontend_1
This is a minimal React frontend to work with your Music App backend at http://localhost:5000

Run:

```bash
npm install
npm start
```