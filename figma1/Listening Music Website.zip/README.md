
  # Listening Music Website

  This is a code bundle for Listening Music Website. The original project is available at https://www.figma.com/design/DX1bL2Q1Ce3rkUP3p3Y21e/Listening-Music-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  