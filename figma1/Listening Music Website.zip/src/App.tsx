import { useState, useEffect } from "react";
import { MusicPlayer } from "./components/MusicPlayer";
import { Playlist } from "./components/Playlist";
import { NowPlaying } from "./components/NowPlaying";
import { Music } from "lucide-react";

interface Song {
  id: number;
  title: string;
  artist: string;
  album: string;
  duration: string;
  coverUrl: string;
}

const mockSongs: Song[] = [
  {
    id: 1,
    title: "Midnight Dreams",
    artist: "Luna Garcia",
    album: "Nocturnal Beats",
    duration: "3:45",
    coverUrl: "https://images.unsplash.com/photo-1644855640845-ab57a047320e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhbGJ1bSUyMGNvdmVyJTIwbXVzaWN8ZW58MXx8fHwxNzYwMjE4OTU0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
  {
    id: 2,
    title: "Electric Waves",
    artist: "DJ Horizon",
    album: "Synth Paradise",
    duration: "4:12",
    coverUrl: "https://images.unsplash.com/photo-1692176548571-86138128e36c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbGVjdHJvbmljJTIwbXVzaWMlMjBkanxlbnwxfHx8fDE3NjAxNDI5NTR8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
  {
    id: 3,
    title: "City Lights",
    artist: "The Urbanites",
    album: "Metropolitan",
    duration: "3:28",
    coverUrl: "https://images.unsplash.com/photo-1607289763283-c9faaa857004?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx1cmJhbiUyMG5pZ2h0JTIwbXVzaWN8ZW58MXx8fHwxNzYwMjYxNDQyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
  {
    id: 4,
    title: "Acoustic Soul",
    artist: "James River",
    album: "Unplugged Sessions",
    duration: "4:05",
    coverUrl: "https://images.unsplash.com/photo-1648561848326-7eb7117274c8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhY291c3RpYyUyMGd1aXRhciUyMGNsb3NlfGVufDF8fHx8MTc2MDIzOTM2M3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
  {
    id: 5,
    title: "Festival Anthem",
    artist: "The Collective",
    album: "Live at Summer",
    duration: "5:20",
    coverUrl: "https://images.unsplash.com/photo-1740459057005-65f000db582f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb25jZXJ0JTIwc3RhZ2UlMjBsaWdodHN8ZW58MXx8fHwxNzYwMTQyOTQ3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
];

export default function App() {
  const [currentSong, setCurrentSong] = useState<Song | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [volume, setVolume] = useState(70);

  useEffect(() => {
    let interval: NodeJS.Timeout;

    if (isPlaying && currentSong) {
      const [mins, secs] = currentSong.duration.split(':').map(Number);
      const totalDuration = mins * 60 + secs;

      interval = setInterval(() => {
        setCurrentTime((prev) => {
          if (prev >= totalDuration) {
            setIsPlaying(false);
            return 0;
          }
          return prev + 1;
        });
      }, 1000);
    }

    return () => clearInterval(interval);
  }, [isPlaying, currentSong]);

  const handlePlayPause = () => {
    setIsPlaying(!isPlaying);
  };

  const handleSongSelect = (song: Song) => {
    if (currentSong?.id === song.id) {
      setIsPlaying(!isPlaying);
    } else {
      setCurrentSong(song);
      setCurrentTime(0);
      setIsPlaying(true);
    }
  };

  const handleNext = () => {
    if (!currentSong) return;
    const currentIndex = mockSongs.findIndex((s) => s.id === currentSong.id);
    const nextIndex = (currentIndex + 1) % mockSongs.length;
    setCurrentSong(mockSongs[nextIndex]);
    setCurrentTime(0);
    setIsPlaying(true);
  };

  const handlePrevious = () => {
    if (!currentSong) return;
    const currentIndex = mockSongs.findIndex((s) => s.id === currentSong.id);
    const prevIndex = currentIndex === 0 ? mockSongs.length - 1 : currentIndex - 1;
    setCurrentSong(mockSongs[prevIndex]);
    setCurrentTime(0);
    setIsPlaying(true);
  };

  const handleSeek = (value: number[]) => {
    setCurrentTime(value[0]);
  };

  const handleVolumeChange = (value: number[]) => {
    setVolume(value[0]);
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <header className="border-b bg-card">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center gap-2">
            <Music className="h-8 w-8 text-primary" />
            <h1>Music Player</h1>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 max-w-7xl mx-auto w-full px-6 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          <NowPlaying currentSong={currentSong} />
          <Playlist
            songs={mockSongs}
            currentSong={currentSong}
            isPlaying={isPlaying}
            onSongSelect={handleSongSelect}
          />
        </div>
      </main>

      {/* Music Player Footer */}
      <MusicPlayer
        currentSong={currentSong}
        isPlaying={isPlaying}
        currentTime={currentTime}
        volume={volume}
        onPlayPause={handlePlayPause}
        onNext={handleNext}
        onPrevious={handlePrevious}
        onSeek={handleSeek}
        onVolumeChange={handleVolumeChange}
      />
    </div>
  );
}
